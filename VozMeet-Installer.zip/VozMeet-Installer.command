#!/bin/sh
# VozMeet Installer — fallback launcher (use if the .app shows "No se encuentra el archivo")
DIR="$(cd "$(dirname "$0")" && pwd)"
PY=""
for candidate in \
    /usr/bin/python3 \
    /opt/homebrew/bin/python3 \
    /usr/local/bin/python3 \
    /Library/Frameworks/Python.framework/Versions/3.11/bin/python3.11 \
    /Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 \
    /Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
    python3; do
    if [ -x "$candidate" ] 2>/dev/null || command -v "$candidate" >/dev/null 2>&1; then
        PY="$candidate"
        break
    fi
done
if [ -z "$PY" ]; then
    osascript -e 'display dialog "Python 3 no encontrado.\n\nInstala Python desde python.org y vuelve a abrir el instalador." buttons {"OK"} default button "OK" with icon stop with title "VozMeet Installer"'
    exit 1
fi
exec "$PY" "$DIR/VozMeet-Installer.app/Contents/MacOS/installer.py" "$@"
